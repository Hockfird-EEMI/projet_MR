<aside>
	<h3>Administration</h3>
	<ul>
		<li><a href="posts.php">Articles</a></li>
		<li><a href="../index.php">Front Office</a></li>
		<li><a href="index.php">Dashboard</a></li>
		<li><a href="post_add.php">Création d'un article</a></li>
		<li><a href="comments.php">Modération de commentaire</a></li>
	</ul>
</aside>
