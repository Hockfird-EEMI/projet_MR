<?php
	include("protection.inc.php");
?>	
<!DOCTYPE html>
<html lang="fr">
<head>
	<title>Back office</title>
	<meta charset="utf-8"/>
</head>
<body>
	<?php include("config.inc.php"); ?>
	<?php include("pdo.inc.php"); ?>

	<?php include("header_bo.inc.php"); ?>

<main>
	<h1>MROptasia</h1>
	
</main>
	<?php include("aside_bo.inc.php"); ?>
</body>
</html>