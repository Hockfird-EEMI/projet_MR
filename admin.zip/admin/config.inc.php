<?php

define("DB_HOST", "localhost");
define("DB_NAME", "pelletier");
define("DB_USER", "pelletier");
define("DB_PASSWORD", "MFxgkATJ4p");
define("DB_CHARSET", "utf8");